const password = document.getElementById('password');
const togglePassword = document.getElementById('togglePassword');

togglePassword.addEventListener('click', () => {
	const showing = password.type === 'text';
	password.type = showing ? 'password' : 'text';
	togglePassword.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
});

document.getElementById('loginForm').addEventListener('submit', event => {
	event.preventDefault();
	alert('UI demo only — connect an authentication backend to sign in.');
});

document.getElementById('googleBtn').addEventListener('click', () => {
	alert('Google sign-in needs OAuth configuration.');
});

document.getElementById('forgot').addEventListener('click', event => {
	event.preventDefault();
	alert('Password recovery needs to be connected to your authentication service.');
});
document.getElementById('createAccount').addEventListener('click', () => {window.location.href = 'create.html';});
   