  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => root.querySelectorAll(s);
  const restaurantSelectionsKey = 'biterushRestaurantSelections';
  const couponStorageKey = 'biterushAppliedCoupon';
  const freeDeliveryThreshold = 299;

  let coupon = localStorage.getItem(couponStorageKey) === 'BITE30' ? 'BITE30' : '';

  function getRestaurantSelections() {
    return window.BiteRushMenus.getRestaurantSelections();
  }

  function createCartItem(item) {
    const article = document.createElement('article');
    article.className = 'item';
    article.dataset.price = item.price;
    article.dataset.cartId = item.id;

    const food = document.createElement('div');
    food.className = 'food';
    if (item.sample) {
      if (item.foodClass) food.classList.add(item.foodClass);
      food.textContent = item.emoji;
    } else {
      const image = document.createElement('img');
      image.className = 'cart-food-image';
      image.src = item.image;
      image.alt = item.name;
      food.appendChild(image);
    }

    const info = document.createElement('div');
    info.className = 'info';
    const heading = document.createElement('h3');
    heading.textContent = item.name;
    const description = document.createElement('p');
    description.textContent = item.sample
      ? item.description
      : `${item.restaurantName} · ${item.description}`;
    const tag = document.createElement('span');
    tag.className = `tag ${item.tagClass || (item.dealName ? 'deal-tag' : '')}`;
    tag.textContent = item.sample
      ? item.tag
      : item.dealName
      ? `${item.dealName} deal`
      : 'Sample menu price';
    const price = document.createElement('div');
    price.className = 'price';
    if (item.originalPrice > item.price) {
      const originalPrice = document.createElement('span');
      originalPrice.className = 'original-price';
      originalPrice.textContent = `₹${item.originalPrice}`;
      price.appendChild(originalPrice);
    }
    const currentPrice = document.createElement('span');
    currentPrice.textContent = `₹${item.price}`;
    price.appendChild(currentPrice);
    info.append(heading, description, tag, price);

    const removeButton = document.createElement('button');
    removeButton.className = 'x';
    removeButton.type = 'button';
    removeButton.textContent = '×';
    removeButton.setAttribute('aria-label', `Remove ${item.name}`);

    const actions = document.createElement('div');
    actions.className = 'actions';
    const quantity = document.createElement('div');
    quantity.className = 'qty';
    const minus = document.createElement('button');
    minus.className = 'minus';
    minus.type = 'button';
    minus.textContent = '−';
    const count = document.createElement('span');
    count.className = 'count';
    count.textContent = item.quantity;
    const plus = document.createElement('button');
    plus.className = 'plus';
    plus.type = 'button';
    plus.textContent = '+';
    quantity.append(minus, count, plus);

    const remove = document.createElement('button');
    remove.className = 'remove';
    remove.type = 'button';
    remove.textContent = '♜';
    remove.setAttribute('aria-label', `Delete ${item.name}`);
    actions.append(quantity, remove);
    article.append(food, info, removeButton, actions);
    return article;
  }

  function renderCartItems() {
    const container = $('#cartItems');
    container.replaceChildren();

    const items = window.BiteRushMenus.getMenuCartItems();
    if (!items.length) {
      const empty = document.createElement('div');
      empty.className = 'empty-cart';
      const heading = document.createElement('h2');
      heading.textContent = 'Your cart is empty';
      const message = document.createElement('p');
      message.textContent = 'Add something delicious to get started.';
      const browse = document.createElement('a');
      browse.className = 'primary empty-cart-link';
      browse.href = 'explore.html';
      browse.textContent = 'Browse Menu →';
      empty.append(heading, message, browse);
      container.appendChild(empty);
      return;
    }

    if (items.some(item => !item.sample)) {
      const note = document.createElement('p');
      note.className = 'menu-cart-note';
      note.textContent = 'Menu items use sample prices.';
      container.appendChild(note);
    }
    items.forEach(item => container.appendChild(createCartItem(item)));
    $$('.item', container).forEach(bindCartItem);
  }

  function persistCartItem(itemElement, remove = false) {
    const itemId = itemElement.dataset.cartId;
    if (!itemId) return;

    const items = window.BiteRushMenus.getMenuCartItems();
    const nextItems = remove
      ? items.filter(item => item.id !== itemId)
      : items.map(item => item.id === itemId
        ? { ...item, quantity: +$('.count', itemElement).textContent }
        : item);
    window.BiteRushMenus.saveMenuCartItems(nextItems);
  }

  function bindCartItem(itemElement) {
    $('.plus', itemElement).onclick = () => {
      $('.count', itemElement).textContent = +$('.count', itemElement).textContent + 1;
      persistCartItem(itemElement);
      update();
    };

    $('.minus', itemElement).onclick = () => {
      const quantity = +$('.count', itemElement).textContent;
      if (quantity > 1) {
        $('.count', itemElement).textContent = quantity - 1;
        persistCartItem(itemElement);
      } else {
        persistCartItem(itemElement, true);
        renderCartItems();
      }
      update();
    };

    const removeItem = () => {
      persistCartItem(itemElement, true);
      renderCartItems();
      update();
    };
    $('.remove', itemElement).onclick = removeItem;
    $('.x', itemElement).onclick = removeItem;
  }

  function toast(m) {
    let t = $('#toast');
    t.textContent = m;
    t.classList.add('show');
    clearTimeout(window.tt);
    window.tt = setTimeout(() => t.classList.remove('show'), 2400);
  }

  function getSubtotal() {
    return Array.from($$('.item', $('#cartItems'))).reduce((subtotal, item) => {
      return subtotal + Number(item.dataset.price) * Number($('.count', item).textContent);
    }, 0);
  }

  function update() {
    const sub = getSubtotal();
    if (sub === 0 && coupon) {
      coupon = '';
      localStorage.removeItem(couponStorageKey);
      $('#couponInput').value = '';
    }

    const items = $$('.item', $('#cartItems'));
    let count = Array.from(items).reduce(
      (total, item) => total + Number($('.count', item).textContent),
      0,
    );
    count += getRestaurantSelections().length;

    const delivery = sub === 0 || sub >= freeDeliveryThreshold ? 0 : 20;
    const taxes = sub === 0 ? 0 : Math.round(sub * .0521);
    const discount = coupon && sub ? Math.min(30, sub) : 0;

    $('#subtotal').textContent = '₹' + sub;
    $('#delivery').textContent = '₹' + delivery;
    $('#taxes').textContent = '₹' + taxes;
    $('#couponDiscount').textContent = '−₹' + discount;
    $('#couponDiscountRow').hidden = discount === 0;
    $('#total').textContent = '₹' + Math.max(0, sub + delivery + taxes - discount);
    $('#badge').textContent = count;
    $('#badge').parentElement.setAttribute('aria-label', `Shopping cart, ${count} items`);
    $('#freeText').textContent = sub === 0
      ? 'Add items to unlock free delivery.'
      : sub >= freeDeliveryThreshold
      ? 'You unlocked free delivery!'
      : 'You’re just ₹' + Math.max(0, freeDeliveryThreshold - sub) + ' away from free delivery!';
    const progress = Math.min(freeDeliveryThreshold, sub);
    $('#bar').style.width = (progress / freeDeliveryThreshold * 100) + '%';
    $('#bar').parentElement.setAttribute('aria-valuemax', freeDeliveryThreshold);
    $('#bar').parentElement.setAttribute('aria-valuenow', progress);
    $('#couponHint').textContent = coupon
      ? 'BITE30 applied. Tap Remove to undo.'
      : 'Use BITE30 for ₹30 off your order.';
    if (coupon) $('#couponInput').value = coupon;
    $('#couponInput').disabled = Boolean(coupon);
    $('#apply').textContent = coupon ? 'Remove' : 'Apply';
    $('#apply').setAttribute('aria-label', coupon ? 'Remove applied coupon' : 'Apply coupon code');
  }

  function renderRestaurantSelections() {
    $('#restaurantSelections')?.remove();

    const selections = getRestaurantSelections();
    if (!selections.length) return;

    const section = document.createElement('section');
    section.className = 'restaurant-selections';
    section.id = 'restaurantSelections';

    const heading = document.createElement('h3');
    heading.textContent = 'Restaurant selections';
    section.appendChild(heading);

    const note = document.createElement('p');
    note.textContent = 'Choose dishes from a restaurant to add priced items to your order.';
    section.appendChild(note);

    const list = document.createElement('ul');
    selections.forEach(name => {
      const item = document.createElement('li');
      const label = document.createElement('span');
      label.textContent = name;

      const remove = document.createElement('button');
      remove.type = 'button';
      remove.textContent = 'Remove';
      remove.setAttribute('aria-label', `Remove ${name} from restaurant selections`);
      remove.onclick = () => {
        const remaining = getRestaurantSelections().filter(selection => selection !== name);
        localStorage.setItem(restaurantSelectionsKey, remaining.join('\n'));
        renderRestaurantSelections();
        update();
      };

      item.append(label, remove);
      list.appendChild(item);
    });
    section.appendChild(list);

    $('#cartPanel').insertBefore(section, $('.coupon'));
  }

  function toggleCoupon() {
    if (coupon) {
      coupon = '';
      localStorage.removeItem(couponStorageKey);
      $('#couponInput').value = '';
      toast('Coupon removed.');
      update();
      return;
    }

    const code = $('#couponInput').value.trim().toUpperCase();
    if (!code) {
      toast('Please enter a coupon code.');
      return;
    }
    if (code !== 'BITE30') {
      toast('Invalid code. Try BITE30.');
      return;
    }
    if (getSubtotal() === 0) {
      toast('Add items to your cart before applying a coupon.');
      return;
    }

    coupon = code;
    localStorage.setItem(couponStorageKey, coupon);
    toast('Coupon applied! ₹30 discount added.');
    update();
  }

  $('#apply').onclick = toggleCoupon;
  $('#couponInput').addEventListener('keydown', event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      toggleCoupon();
    }
  });

  $('#checkout').onclick = () => toast(
    window.BiteRushMenus.getMenuCartItems().length
      ? 'Checkout prototype — connect a payment backend to continue.'
      : 'Your cart is empty.'
  );

  document.querySelectorAll('.navlinks [data-inert]').forEach(link => {
    link.addEventListener('click', event => event.preventDefault());
  });

  document.addEventListener('keydown', event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      $('#search').focus();
    }
  });

  $('#location').addEventListener('click', () => {
    $('#locationInput').value = $('#location').textContent.trim().replace(/\s*⌄$/, '');
    $('#locationDialog').showModal();
  });

  $('#saveLocation').addEventListener('click', () => {
    const place = $('#locationInput').value.trim();
    if (!place) {
      $('#locationInput').focus();
      return;
    }

    $('#location').textContent = `${place}　⌄`;
    $('#locationDialog').close();
  });

  renderCartItems();
  renderRestaurantSelections();
  update();
