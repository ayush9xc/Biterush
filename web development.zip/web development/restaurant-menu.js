const restaurantId = document.body.dataset.restaurant;
const restaurant = window.BiteRushMenus.restaurants[restaurantId];

if (!restaurant) {
  throw new Error(`Unknown restaurant page: ${restaurantId}`);
}

document.title = `BiteRush — ${restaurant.name} Menu`;
document.getElementById("restaurantName").textContent = restaurant.name;
document.getElementById("restaurantCuisine").textContent = restaurant.cuisine;
document.getElementById("restaurantImage").src = restaurant.image;
document.getElementById("restaurantImage").alt = `${restaurant.name} food`;
document.getElementById("restaurantRating").textContent =
  `★ ${restaurant.rating} (${restaurant.reviews})`;
document.getElementById("restaurantDelivery").textContent =
  `◷ ${restaurant.delivery}`;

function updateCartBadge() {
  const count = window.BiteRushMenus.getCartCount();
  document.getElementById("cartCount").textContent = count;
  document
    .getElementById("cartLink")
    .setAttribute("aria-label", `Shopping cart, ${count} items`);
}

function toast(message, showCartLink = false) {
  const toastElement = document.getElementById("toast");
  toastElement.replaceChildren();
  const messageElement = document.createElement("span");
  messageElement.textContent = message;
  toastElement.appendChild(messageElement);

  if (showCartLink) {
    const link = document.createElement("a");
    link.className = "toast-cart-link";
    link.href = "cart.html";
    link.textContent = "View Cart";
    toastElement.appendChild(link);
  }

  toastElement.classList.add("show");
  clearTimeout(window.menuToastTimer);
  window.menuToastTimer = setTimeout(
    () => {
      toastElement.classList.remove("show");
      toastElement.replaceChildren();
    },
    showCartLink ? 5000 : 2200,
  );
}

function createDishCard(dish) {
  const card = document.createElement("article");
  card.className = "dish-card";

  const image = document.createElement("img");
  image.className = "dish-photo";
  image.src = dish.image;
  image.alt = dish.name;
  card.appendChild(image);

  const info = document.createElement("div");
  info.className = "dish-info";

  const name = document.createElement("h3");
  name.textContent = dish.name;
  info.appendChild(name);

  const description = document.createElement("p");
  description.textContent = dish.description;
  info.appendChild(description);

  const bottom = document.createElement("div");
  bottom.className = "dish-bottom";
  const price = document.createElement("span");
  price.className = "dish-price";
  price.textContent = `₹${dish.price}`;
  const tag = document.createElement("span");
  tag.className = "dish-tag";
  tag.textContent = "Popular choice";
  bottom.append(price, tag);
  info.appendChild(bottom);

  const actions = document.createElement("div");
  actions.className = "dish-actions";

  const addButton = document.createElement("button");
  addButton.className = "add-dish";
  addButton.type = "button";
  addButton.textContent = "Add to Cart";
  addButton.addEventListener("click", () => {
    window.BiteRushMenus.addDishToCart(restaurantId, dish.id);
    updateCartBadge();
    toast(`${dish.name} added to cart.`, true);
  });

  const orderButton = document.createElement("button");
  orderButton.className = "order-dish";
  orderButton.type = "button";
  orderButton.textContent = "Order Now";
  orderButton.addEventListener("click", () => {
    window.BiteRushMenus.addDishToCart(restaurantId, dish.id);
    window.location.href = "cart.html";
  });

  actions.append(addButton, orderButton);
  info.appendChild(actions);
  card.appendChild(info);
  return card;
}

const dishGrid = document.getElementById("dishGrid");
restaurant.dishes.forEach((dish) => dishGrid.appendChild(createDishCard(dish)));

const menuSearch = document.getElementById("search");
if (menuSearch) {
  const emptySearch = document.createElement("p");
  emptySearch.className = "menu-search-empty";
  emptySearch.setAttribute("role", "status");
  emptySearch.hidden = true;
  emptySearch.textContent = "No dishes match your search. Try another name.";
  dishGrid.after(emptySearch);
  menuSearch.addEventListener("input", () => {
    const query = menuSearch.value.trim().toLowerCase();
    let visible = 0;
    dishGrid.querySelectorAll(".dish-card").forEach((card) => {
      const matches = card.textContent.toLowerCase().includes(query);
      card.hidden = !matches;
      if (matches) visible += 1;
    });
    emptySearch.hidden = visible > 0;
  });
}

updateCartBadge();
window.addEventListener("pageshow", updateCartBadge);
