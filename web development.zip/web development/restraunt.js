const search = document.querySelector("#search"),
  grid = document.querySelector("#grid"),
  count = document.querySelector("#resultCount"),
  sort = document.querySelector("#sort");
const cards = [...document.querySelectorAll(".restaurant")];
function updateCartBadge() {
  const cartCount = window.BiteRushMenus.getCartCount();
  const cart = document.querySelector(".cart");
  cart.querySelector(".count").textContent = cartCount;
  cart.setAttribute("aria-label", `Shopping cart, ${cartCount} items`);
}

cards.forEach((card) => {
  const restaurant = window.BiteRushMenus.restaurants[card.dataset.menu];
  const menuLink = document.createElement("a");
  menuLink.className = "view-menu";
  menuLink.href = restaurant.page;
  menuLink.textContent = "View Menu";
  card.querySelector(".details").appendChild(menuLink);
});

updateCartBadge();
window.addEventListener("pageshow", updateCartBadge);

function applyFilters() {
  const q = search.value.toLowerCase().trim();
  const cuisines = [
    ...document.querySelectorAll('input[name="cuisine"]:checked'),
  ].map((x) => x.value);
  const ratings = [
    ...document.querySelectorAll('input[name="rating"]:checked'),
  ].map((x) => Number(x.value));
  const food = [...document.querySelectorAll('input[name="food"]:checked')].map(
    (x) => x.value,
  );
  const minRating = ratings.length ? Math.max(...ratings) : 0;
  let shown = 0;
  cards.forEach((card) => {
    const matchesText = (
      card.dataset.name +
      " " +
      card.dataset.cuisine
    ).includes(q);
    const matchesCuisine =
      !cuisines.length ||
      cuisines.some((c) => card.dataset.cuisine.includes(c));
    const matchesRating = Number(card.dataset.rating) >= minRating;
    const matchesFood =
      !food.length ||
      food.includes("both") ||
      food.includes(card.dataset.food) ||
      card.dataset.food === "both";
    const visible =
      matchesText && matchesCuisine && matchesRating && matchesFood;
    card.style.display = visible ? "" : "none";
    if (visible) shown++;
  });
  count.textContent =
    shown === cards.length
      ? "120+ Restaurants found"
      : `${shown} Restaurants found`;
  document.querySelector("#empty").style.display = shown ? "none" : "block";
}
search.addEventListener("input", applyFilters);
document.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    search.focus();
  }
});
document.querySelector("#location").addEventListener("click", () => {
  const place = prompt("Enter your delivery location:", "Chandigarh, 160036");
  if (place && place.trim()) {
    document.querySelector("#location").textContent = `${place.trim()}　⌄`;
  }
});
document
  .querySelectorAll(".filters input")
  .forEach((x) => x.addEventListener("change", applyFilters));
document.querySelector("#clear").addEventListener("click", () => {
  document
    .querySelectorAll(".filters input")
    .forEach((x) => (x.checked = false));
  document.querySelector('input[name="food"][value="both"]').checked = true;
  search.value = "";
  applyFilters();
});
const filterToggle = document.querySelector("#filterToggle");
const filtersPanel = document.querySelector("#filtersPanel");
const filterBody = document.querySelector("#filterBody");
const mainLayout = document.querySelector(".main");
filterToggle.addEventListener("click", () => {
  const expanded = filterToggle.getAttribute("aria-expanded") === "true";
  filterToggle.setAttribute("aria-expanded", String(!expanded));
  filterToggle.setAttribute("aria-label", expanded ? "Show filters" : "Hide filters");
  filterToggle.title = expanded ? "Show filters" : "Hide filters";
  filterToggle.firstElementChild.textContent = expanded ? "›" : "‹";
  filtersPanel.classList.toggle("is-collapsed", expanded);
  mainLayout.classList.toggle("filters-collapsed", expanded);
  filterBody.setAttribute("aria-hidden", String(expanded));
  filterBody.toggleAttribute("inert", expanded);
  document.querySelector("#clear").hidden = expanded;
});
sort.addEventListener("change", () => {
  const sorted = [...cards];
  if (sort.value === "rating")
    sorted.sort((a, b) => Number(b.dataset.rating) - Number(a.dataset.rating));
  if (sort.value === "name")
    sorted.sort((a, b) => a.dataset.name.localeCompare(b.dataset.name));
  if (sort.value === "popular")
    sorted.sort((a, b) => cards.indexOf(a) - cards.indexOf(b));
  sorted.forEach((c) => grid.insertBefore(c, document.querySelector("#empty")));
});
document.querySelectorAll(".heart").forEach((btn) =>
  btn.addEventListener("click", () => {
    btn.classList.toggle("liked");
    btn.textContent = btn.classList.contains("liked") ? "♥" : "♡";
  }),
);
