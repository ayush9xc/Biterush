(() => {
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const search = document.querySelector("#search");
  const mainContent = document.querySelector("main");
  if (mainContent) {
    if (!mainContent.id) mainContent.id = "brMainContent";
    const skipLink = document.createElement("a");
    skipLink.className = "br-skip-link";
    skipLink.href = `#${mainContent.id}`;
    skipLink.textContent = "Skip to main content";
    document.body.prepend(skipLink);
  }

  const progress = document.createElement("div");
  progress.className = "br-scroll-progress";
  progress.setAttribute("aria-hidden", "true");
  document.body.prepend(progress);

  const backToTop = document.createElement("button");
  backToTop.className = "br-back-to-top";
  backToTop.type = "button";
  backToTop.setAttribute("aria-label", "Back to top");
  backToTop.textContent = "↑";
  backToTop.hidden = true;
  document.body.append(backToTop);

  const soundToggle = document.createElement("button");
  soundToggle.className = "br-sound-toggle";
  soundToggle.type = "button";
  soundToggle.setAttribute("aria-pressed", "false");
  document.body.append(soundToggle);

  const soundStatus = document.createElement("div");
  soundStatus.className = "br-sound-status";
  soundStatus.setAttribute("role", "status");
  soundStatus.setAttribute("aria-live", "polite");
  soundStatus.setAttribute("aria-atomic", "true");
  document.body.append(soundStatus);

  const soundPreferenceKey = "biterush-sound-effects";
  const AudioContextConstructor = window.AudioContext;
  let audioContext;
  let soundStatusTimer;
  let soundEnabled = false;

  function showSoundStatus(message, visible = false) {
    soundStatus.textContent = message;
    soundStatus.classList.toggle("is-visible", visible);
    window.clearTimeout(soundStatusTimer);
    if (visible) {
      soundStatusTimer = window.setTimeout(() => {
        soundStatus.classList.remove("is-visible");
      }, 4500);
    }
  }

  function updateSoundToggle() {
    soundToggle.textContent = soundEnabled ? "🔊" : "🔇";
    soundToggle.setAttribute("aria-pressed", String(soundEnabled));
    soundToggle.setAttribute("aria-label", `${soundEnabled ? "Disable" : "Enable"} sound effects`);
    soundToggle.title = `${soundEnabled ? "Disable" : "Enable"} sound effects`;
  }

  function setSoundEnabled(enabled) {
    soundEnabled = enabled;
    updateSoundToggle();
    let saved = true;
    try {
      window.localStorage.setItem(soundPreferenceKey, String(enabled));
    } catch (error) {
      console.error("Could not save the sound-effects preference.", error);
      showSoundStatus("Sound effects will only stay set for this visit.", true);
      saved = false;
    }

    if (!enabled && audioContext) {
      const contextToClose = audioContext;
      audioContext = undefined;
      contextToClose.close().catch((error) => {
        console.error("Could not close the sound-effects audio context.", error);
      });
    }
    return saved;
  }

  function disableSoundToggle() {
    soundToggle.disabled = true;
    soundToggle.setAttribute("aria-label", "Sound effects are unavailable");
    soundToggle.title = "Sound effects are unavailable in this browser.";
  }

  function handleSoundError(message, error) {
    console.error(message, error);
    setSoundEnabled(false);
    showSoundStatus(message, true);
  }

  function playSoundCue(cue) {
    if (!soundEnabled) return;
    if (!AudioContextConstructor) {
      disableSoundToggle();
      showSoundStatus("Sound effects are unavailable in this browser.", true);
      return;
    }

    try {
      audioContext ??= new AudioContextConstructor();
      const notes = {
        click: [{ frequency: 560, duration: 0.045, volume: 0.022 }],
        scroll: [
          { frequency: 350, delay: 0, duration: 0.028, volume: 0.016, waveform: "triangle" },
          { frequency: 285, delay: 0.03, duration: 0.028, volume: 0.016, waveform: "triangle" },
          { frequency: 350, delay: 0.06, duration: 0.028, volume: 0.016, waveform: "triangle" },
          { frequency: 285, delay: 0.13, duration: 0.028, volume: 0.016, waveform: "triangle" },
          { frequency: 350, delay: 0.16, duration: 0.028, volume: 0.016, waveform: "triangle" },
          { frequency: 285, delay: 0.19, duration: 0.028, volume: 0.016, waveform: "triangle" },
        ],
        success: [
          { frequency: 660, delay: 0, duration: 0.09, volume: 0.035 },
          { frequency: 880, delay: 0.085, duration: 0.12, volume: 0.03 },
        ],
        error: [{ frequency: 300, duration: 0.1, volume: 0.024 }],
      }[cue];

      const play = () => {
        if (!soundEnabled) return;
        const now = audioContext.currentTime;
        notes.forEach(({ frequency, delay = 0, duration, volume, waveform = "sine" }) => {
          const oscillator = audioContext.createOscillator();
          const gain = audioContext.createGain();
          const start = now + delay;
          oscillator.type = waveform;
          oscillator.frequency.setValueAtTime(frequency, start);
          gain.gain.setValueAtTime(0.001, start);
          gain.gain.exponentialRampToValueAtTime(volume, start + 0.012);
          gain.gain.exponentialRampToValueAtTime(0.001, start + duration);
          oscillator.connect(gain);
          gain.connect(audioContext.destination);
          oscillator.start(start);
          oscillator.stop(start + duration + 0.01);
        });
      };

      if (audioContext.state === "suspended") {
        audioContext.resume().then(play).catch((error) => {
          handleSoundError("Sound could not start. Check your browser's audio settings and try again.", error);
        });
      } else {
        play();
      }
    } catch (error) {
      handleSoundError("Sound effects could not be played in this browser.", error);
    }
  }

  soundToggle.addEventListener("click", () => {
    const saved = setSoundEnabled(!soundEnabled);
    if (saved) showSoundStatus(`Sound effects ${soundEnabled ? "on" : "off"}.`);
    if (soundEnabled) playSoundCue("success");
  });

  try {
    soundEnabled = window.localStorage.getItem(soundPreferenceKey) === "true";
  } catch (error) {
    console.error("Could not read the sound-effects preference.", error);
    showSoundStatus("Your saved sound setting could not be loaded.", true);
  }
  updateSoundToggle();

  if (!AudioContextConstructor) {
    disableSoundToggle();
  }

  document.addEventListener("click", (event) => {
    const target = event.target instanceof Element
      ? event.target.closest("button:not(:disabled), a[href], select")
      : null;
    if (!target || target === soundToggle) return;
    playSoundCue("click");
  });

  let lastCuisineHoverCueAt = Number.NEGATIVE_INFINITY;
  document.addEventListener("pointerover", (event) => {
    if (!soundEnabled || event.pointerType === "touch") return;
    const cuisine = event.target instanceof Element
      ? event.target.closest(".cuisine")
      : null;
    if (!cuisine) return;
    if (event.relatedTarget instanceof Node && cuisine.contains(event.relatedTarget)) return;

    const now = window.performance.now();
    if (now - lastCuisineHoverCueAt < 220) return;
    lastCuisineHoverCueAt = now;
    playSoundCue("scroll");
  });

  document.querySelectorAll('[role="status"]').forEach((status) => {
    let previousMessage = status.textContent.trim();
    const statusObserver = new MutationObserver(() => {
      const message = status.textContent.trim();
      if (!message || message === previousMessage) return;
      previousMessage = message;
      if (/\b(?:added to (?:your )?cart|coupon applied)\b/i.test(message)) {
        playSoundCue("success");
      } else if (/\b(?:invalid|could not|unable|failed|error)\b/i.test(message)) {
        playSoundCue("error");
      }
    });
    statusObserver.observe(status, { childList: true, characterData: true, subtree: true });
  });

  function updateScrollControls() {
    const scrollableHeight = document.documentElement.scrollHeight - window.innerHeight;
    const scrollProgress = scrollableHeight > 0 ? window.scrollY / scrollableHeight : 0;
    progress.style.transform = `scaleX(${Math.min(1, Math.max(0, scrollProgress))})`;
    backToTop.hidden = window.scrollY < 650;
  }

  let scrollUpdateScheduled = false;
  window.addEventListener("scroll", () => {
    if (scrollUpdateScheduled) return;
    scrollUpdateScheduled = true;
    window.requestAnimationFrame(() => {
      scrollUpdateScheduled = false;
      updateScrollControls();
    });
  }, { passive: true });
  window.addEventListener("resize", updateScrollControls);
  document.addEventListener("visibilitychange", () => {
    scrollUpdateScheduled = false;
    updateScrollControls();
  });
  backToTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" });
  });
  updateScrollControls();

  if (search) {
    search.setAttribute("aria-keyshortcuts", "Control+K Meta+K");
    document.addEventListener("keydown", (event) => {
      if (event.defaultPrevented) return;
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        search.focus();
      } else if (event.key === "Escape" && document.activeElement === search) {
        search.blur();
      }
    });
  }

  if (reducedMotion || !("IntersectionObserver" in window)) return;

  const revealTargets = [...document.querySelectorAll([
    "main section",
    "main article",
    ".restaurant",
    ".offer-card",
    ".home-restaurant-card",
    ".home-dish-card",
    ".category",
    ".filters",
    ".free-card",
    ".panel",
    ".summary",
    ".feature",
    ".benefit",
  ].join(","))].filter((element) => !element.hidden && !element.closest("[hidden], [role='dialog']"));

  if (!revealTargets.length) return;

  document.documentElement.classList.add("br-motion-ready");
  revealTargets.forEach((element) => {
    const siblings = [...element.parentElement.children];
    const index = siblings.indexOf(element);
    element.classList.add("br-reveal");
    element.style.setProperty("--br-reveal-delay", `${Math.min(index, 5) * 55}ms`);
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("br-visible");
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -24px 0px" });

  revealTargets.forEach((element) => observer.observe(element));
})();
