const offers = [
  {
    id: 'mcd-burger-rush',
    restaurantId: 'mcdonalds',
    dishId: 'mcdonalds-mcaloo-tikki',
    dealName: 'Burger Rush',
    kind: 'Restaurant Deal',
    price: 69,
    description: 'McDonald’s classic veggie burger at a special BiteRush price.',
  },
  {
    id: 'dominos-pizza-party',
    restaurantId: 'dominos',
    dishId: 'dominos-margherita',
    dealName: 'Pizza Party',
    kind: 'Restaurant Deal',
    price: 139,
    description: 'A cheesy Domino’s favourite, marked down for a limited time.',
  },
  {
    id: 'haldirams-chaat-break',
    restaurantId: 'haldirams',
    dishId: 'haldirams-raj-kachori',
    dealName: 'Chaat Break',
    kind: 'Restaurant Deal',
    price: 99,
    description: 'Haldiram’s crispy, tangy Raj Kachori at a bite-size price.',
  },
  {
    id: 'chinese-wok-noodle-drop',
    restaurantId: 'chineseWok',
    dishId: 'chinese-wok-hakka-noodles',
    dealName: 'Noodle Drop',
    kind: 'Dish Deal',
    price: 149,
    description: 'Wok-tossed veggie noodles with an extra-light price.',
  },
  {
    id: 'wow-momo-momo-mania',
    restaurantId: 'wowMomo',
    dishId: 'wow-momo-steamed-veg',
    dealName: 'Momo Mania',
    kind: 'Dish Deal',
    price: 79,
    description: 'Soft, spicy steamed momos that are seriously good value.',
  },
  {
    id: 'theobroma-sweet-treat',
    restaurantId: 'theobroma',
    dishId: 'theobroma-truffle-pastry',
    dealName: 'Sweet Treat',
    kind: 'Dish Deal',
    price: 99,
    description: 'A rich chocolate truffle treat with an even sweeter price.',
  },
];

const dealGrid = document.getElementById('dealGrid');
const emptyOffers = document.getElementById('emptyOffers');
const dealsCount = document.getElementById('dealsCount');
const search = document.getElementById('search');
const toastElement = document.getElementById('toast');
let toastTimer;

function updateCartBadge() {
  const count = window.BiteRushMenus.getCartCount();
  document.querySelector('#cartz .count').textContent = count;
  document.getElementById('cartz').setAttribute(
    'aria-label',
    `Shopping cart, ${count} items`,
  );
}

function toast(message) {
  toastElement.replaceChildren();
  const messageElement = document.createElement('span');
  messageElement.textContent = message;
  const link = document.createElement('a');
  link.href = 'cart.html';
  link.textContent = 'View Cart';
  toastElement.append(messageElement, link);
  toastElement.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toastElement.classList.remove('show');
    toastElement.replaceChildren();
  }, 5000);
}

function createOfferCard(offer) {
  const restaurant = window.BiteRushMenus.restaurants[offer.restaurantId];
  if (!restaurant) throw new Error(`Unknown restaurant offer: ${offer.restaurantId}`);
  const dish = restaurant.dishes.find((item) => item.id === offer.dishId);
  if (!dish) throw new Error(`Unknown dish offer: ${offer.dishId}`);
  if (offer.price <= 0 || offer.price >= dish.price) {
    throw new Error(`Invalid deal price for ${dish.name}`);
  }

  const card = document.createElement('article');
  card.className = 'offer-card';
  card.dataset.search = `${restaurant.name} ${dish.name} ${offer.dealName} ${offer.kind}`.toLowerCase();

  const photo = document.createElement('div');
  photo.className = 'offer-photo';
  const image = document.createElement('img');
  image.src = dish.image;
  image.alt = dish.name;
  const discount = Math.round((1 - offer.price / dish.price) * 100);
  const discountBadge = document.createElement('span');
  discountBadge.className = 'offer-discount';
  discountBadge.textContent = `${discount}% OFF`;
  const kind = document.createElement('span');
  kind.className = 'offer-kind';
  kind.textContent = offer.kind;
  photo.append(image, discountBadge, kind);

  const content = document.createElement('div');
  content.className = 'offer-content';
  const restaurantName = document.createElement('p');
  restaurantName.className = 'offer-restaurant';
  restaurantName.textContent = `${restaurant.name} · ★ ${restaurant.rating}`;
  const title = document.createElement('h3');
  title.textContent = dish.name;
  const description = document.createElement('p');
  description.className = 'offer-description';
  description.textContent = offer.description;

  const prices = document.createElement('div');
  prices.className = 'offer-prices';
  const dealPrice = document.createElement('strong');
  dealPrice.className = 'offer-price';
  dealPrice.textContent = `₹${offer.price}`;
  const originalPrice = document.createElement('span');
  originalPrice.className = 'offer-original-price';
  originalPrice.textContent = `₹${dish.price}`;
  prices.append(dealPrice, originalPrice);

  const actions = document.createElement('div');
  actions.className = 'offer-actions';
  const addButton = document.createElement('button');
  addButton.type = 'button';
  addButton.textContent = 'Add Deal to Cart';
  addButton.addEventListener('click', () => {
    window.BiteRushMenus.addDealToCart(
      offer.restaurantId,
      offer.dishId,
      offer.id,
      offer.dealName,
      offer.price,
    );
    updateCartBadge();
    toast(`${dish.name} deal added to your cart.`);
  });
  const menuLink = document.createElement('a');
  menuLink.className = 'offer-menu-link';
  menuLink.href = restaurant.page;
  menuLink.textContent = 'View Menu';
  actions.append(addButton, menuLink);

  content.append(restaurantName, title, description, prices, actions);
  card.append(photo, content);
  return card;
}

offers.forEach((offer) => dealGrid.appendChild(createOfferCard(offer)));

function filterOffers() {
  const query = search.value.toLowerCase().trim();
  let visibleCount = 0;
  document.querySelectorAll('.offer-card').forEach((card) => {
    const visible = !query || card.dataset.search.includes(query);
    card.hidden = !visible;
    if (visible) visibleCount += 1;
  });
  emptyOffers.hidden = visibleCount > 0;
  dealsCount.textContent = `${visibleCount} ${visibleCount === 1 ? 'deal' : 'deals'} found`;
}

search.addEventListener('input', filterOffers);
document.addEventListener('keydown', (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    search.focus();
  }
});
document.getElementById('cartz').addEventListener('click', () => {
  window.location.href = 'cart.html';
});
document.getElementById('signin').addEventListener('click', () => {
  window.location.href = 'sign.html';
});
document.getElementById('location').addEventListener('click', () => {
  const place = prompt('Enter your delivery location:', 'Phagwara, Punjab');
  if (place && place.trim()) {
    document.getElementById('location').textContent = `${place.trim()}　⌄`;
  }
});

filterOffers();
updateCartBadge();
window.addEventListener('pageshow', updateCartBadge);
