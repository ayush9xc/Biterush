(() => {
  const menus = window.BiteRushMenus;
  if (!menus) {
    console.error("BiteRushMenus is unavailable; home page content was not rendered.");
    return;
  }

  const restaurantEntries = Object.entries(menus.restaurants).sort(
    ([, first], [, second]) => Number(second.rating) - Number(first.rating),
  );
  const featuredDishes = [
    ["mcdonalds", "mcdonalds-mcaloo-tikki"],
    ["dominos", "dominos-farmhouse"],
    ["kfc", "kfc-hot-crispy"],
    ["haldirams", "haldirams-chole-bhature"],
    ["chineseWok", "chinese-wok-hakka-noodles"],
    ["theobroma", "theobroma-truffle-pastry"],
  ];

  const cart = document.querySelector("#cartz");
  const searchInput = document.querySelector("#search");
  const restaurantGrid = document.querySelector("#homeRestaurantGrid");
  const dishGrid = document.querySelector("#homeDishGrid");
  const restaurantSection = document.querySelector("#homeRestaurantsSection");
  const dishSection = document.querySelector("#homeDishesSection");
  const searchEmpty = document.querySelector("#homeSearchEmpty");
  const restaurantSliderPrev = document.querySelector("#homeRestaurantPrev");
  const restaurantSliderNext = document.querySelector("#homeRestaurantNext");
  const toast = document.querySelector("#homeToast");
  const locationButton = document.querySelector("#location");
  const locationDialog = document.querySelector("#homeLocationDialog");
  const locationForm = document.querySelector("#homeLocationForm");
  const locationInput = document.querySelector("#homeLocationInput");
  let currentLocation = locationButton.textContent.replace(/\s*⌄$/, "").trim();
  let toastTimer;

  function updateCartBadge() {
    const count = menus.getCartCount();
    cart.querySelector(".count").textContent = count;
    cart.setAttribute("aria-label", `Shopping cart, ${count} items`);
  }

  function showToast(message) {
    toast.replaceChildren();
    const text = document.createElement("span");
    text.textContent = message;
    const viewCart = document.createElement("a");
    viewCart.href = "cart.html";
    viewCart.textContent = "View cart";
    toast.append(text, viewCart);
    toast.classList.add("is-visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 3500);
  }

  function openLocationDialog() {
    locationInput.value = currentLocation;
    locationDialog.hidden = false;
    locationButton.setAttribute("aria-expanded", "true");
    locationInput.focus();
  }

  function closeLocationDialog() {
    if (locationDialog.hidden) return;
    locationDialog.hidden = true;
    locationButton.setAttribute("aria-expanded", "false");
    locationButton.focus();
  }

  function searchableText(restaurant) {
    return [
      restaurant.name,
      restaurant.cuisine,
      ...restaurant.dishes.flatMap((dish) => [dish.name, dish.description]),
    ].join(" ").toLowerCase();
  }

  function makeRestaurantCard(restaurant) {
    const card = document.createElement("article");
    card.className = "home-restaurant-card";
    card.dataset.search = searchableText(restaurant);

    const imageLink = document.createElement("a");
    imageLink.className = "home-restaurant-image";
    imageLink.href = restaurant.page;
    imageLink.setAttribute("aria-label", `View ${restaurant.name} menu`);
    const image = document.createElement("img");
    image.src = restaurant.image;
    image.alt = restaurant.name;
    image.loading = "lazy";
    imageLink.append(image);

    const copy = document.createElement("div");
    copy.className = "home-restaurant-copy";
    const title = document.createElement("h3");
    title.textContent = restaurant.name;
    const cuisine = document.createElement("p");
    cuisine.className = "home-restaurant-cuisine";
    cuisine.textContent = restaurant.cuisine;

    const details = document.createElement("div");
    details.className = "home-restaurant-details";
    const rating = document.createElement("span");
    rating.className = "home-rating";
    rating.textContent = `★ ${restaurant.rating}`;
    const delivery = document.createElement("span");
    delivery.textContent = restaurant.delivery;
    details.append(rating, delivery);

    const menuLink = document.createElement("a");
    menuLink.className = "home-menu-link";
    menuLink.href = restaurant.page;
    menuLink.textContent = "View menu";
    menuLink.setAttribute("aria-label", `View ${restaurant.name} menu`);
    copy.append(title, cuisine, details, menuLink);
    card.append(imageLink, copy);
    return card;
  }

  function makeDishCard(restaurantId, dish) {
    const restaurant = menus.restaurants[restaurantId];
    const card = document.createElement("article");
    card.className = "home-dish-card";
    card.dataset.search = [
      restaurant.name,
      restaurant.cuisine,
      dish.name,
      dish.description,
    ].join(" ").toLowerCase();

    const imageLink = document.createElement("a");
    imageLink.className = "home-dish-image";
    imageLink.href = restaurant.page;
    imageLink.setAttribute("aria-label", `View ${dish.name} at ${restaurant.name}`);
    const image = document.createElement("img");
    image.src = dish.image;
    image.alt = dish.name;
    image.loading = "lazy";
    imageLink.append(image);

    const copy = document.createElement("div");
    copy.className = "home-dish-copy";
    const source = document.createElement("p");
    source.className = "home-dish-source";
    source.textContent = restaurant.name;
    const title = document.createElement("h3");
    title.textContent = dish.name;
    const description = document.createElement("p");
    description.className = "home-dish-description";
    description.textContent = dish.description;

    const footer = document.createElement("div");
    footer.className = "home-dish-footer";
    const price = document.createElement("strong");
    price.className = "home-dish-price";
    price.textContent = `₹${dish.price}`;
    const actions = document.createElement("div");
    actions.className = "home-dish-actions";

    const addButton = document.createElement("button");
    addButton.className = "home-add-button";
    addButton.type = "button";
    addButton.textContent = "Add to cart";
    addButton.addEventListener("click", () => addDishToCart(restaurantId, dish.id));

    const orderButton = document.createElement("button");
    orderButton.className = "home-order-button";
    orderButton.type = "button";
    orderButton.textContent = "Order now";
    orderButton.addEventListener("click", () => addDishToCart(restaurantId, dish.id, true));

    actions.append(addButton, orderButton);
    footer.append(price, actions);
    copy.append(source, title, description, footer);
    card.append(imageLink, copy);
    return card;
  }

  function updateRestaurantSliderControls() {
    const maxScroll = restaurantGrid.scrollWidth - restaurantGrid.clientWidth;
    restaurantSliderPrev.disabled = maxScroll <= 1 || restaurantGrid.scrollLeft <= 1;
    restaurantSliderNext.disabled = maxScroll <= 1 || restaurantGrid.scrollLeft >= maxScroll - 1;
  }

  function scrollRestaurantSlider(direction) {
    const firstVisibleCard = restaurantGrid.querySelector(".home-restaurant-card:not([hidden])");
    if (!firstVisibleCard) return;

    const gap = Number.parseFloat(getComputedStyle(restaurantGrid).columnGap) || 0;
    const distance = firstVisibleCard.getBoundingClientRect().width + gap;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    restaurantGrid.scrollBy({ left: direction * distance, behavior: reducedMotion ? "auto" : "smooth" });
  }

  function addDishToCart(restaurantId, dishId, orderNow = false) {
    let dish;
    try {
      dish = menus.addDishToCart(restaurantId, dishId);
    } catch (error) {
      console.error("Could not add the dish to the cart.", error);
      showToast("That dish could not be added. Please try again.");
      return;
    }

    updateCartBadge();
    if (orderNow) {
      window.location.href = "cart.html";
      return;
    }
    showToast(`${dish.name} added to your cart.`);
  }

  function filterHomeContent() {
    const query = searchInput.value.trim().toLowerCase();
    let restaurantMatches = 0;
    let dishMatches = 0;

    restaurantGrid.scrollLeft = 0;
    restaurantGrid.querySelectorAll(".home-restaurant-card").forEach((card) => {
      const matches = !query || card.dataset.search.includes(query);
      card.hidden = !matches;
      if (matches) restaurantMatches += 1;
    });

    dishGrid.querySelectorAll(".home-dish-card").forEach((card) => {
      const matches = !query || card.dataset.search.includes(query);
      card.hidden = !matches;
      if (matches) dishMatches += 1;
    });

    restaurantSection.hidden = Boolean(query) && restaurantMatches === 0;
    dishSection.hidden = Boolean(query) && dishMatches === 0;
    searchEmpty.hidden = !query || restaurantMatches + dishMatches > 0;
    if (!searchEmpty.hidden) {
      searchEmpty.textContent = `No restaurants or dishes found for “${searchInput.value.trim()}”. Try another search.`;
    }
    updateRestaurantSliderControls();
  }

  restaurantEntries.forEach(([, restaurant]) => {
    restaurantGrid.append(makeRestaurantCard(restaurant));
  });

  featuredDishes.forEach(([restaurantId, dishId]) => {
    const restaurant = menus.restaurants[restaurantId];
    const dish = restaurant?.dishes.find((item) => item.id === dishId);
    if (!dish) {
      throw new Error(`Featured dish ${dishId} is missing from restaurant ${restaurantId}.`);
    }
    dishGrid.append(makeDishCard(restaurantId, dish));
  });

  updateCartBadge();
  restaurantSliderPrev.addEventListener("click", () => scrollRestaurantSlider(-1));
  restaurantSliderNext.addEventListener("click", () => scrollRestaurantSlider(1));
  restaurantGrid.addEventListener("scroll", updateRestaurantSliderControls, { passive: true });
  window.addEventListener("resize", updateRestaurantSliderControls);
  document.addEventListener("visibilitychange", updateRestaurantSliderControls);
  filterHomeContent();
  window.addEventListener("pageshow", updateCartBadge);
  searchInput.addEventListener("input", filterHomeContent);

  document.addEventListener("keydown", (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      searchInput.focus();
    }
  });

  searchInput.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    const query = searchInput.value.trim().toLowerCase();
    if (!query) return;
    const match = restaurantEntries.find(([, restaurant]) => searchableText(restaurant).includes(query));
    if (match) window.location.href = match[1].page;
  });

  document.querySelector("#explore").addEventListener("click", () => {
    window.location.href = "restraunt.html";
  });

  locationButton.addEventListener("click", openLocationDialog);
  document.querySelector("#closeLocationDialog").addEventListener("click", closeLocationDialog);
  document.querySelector("#cancelLocation").addEventListener("click", closeLocationDialog);
  locationDialog.addEventListener("click", (event) => {
    if (event.target === locationDialog) closeLocationDialog();
  });
  locationDialog.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeLocationDialog();
      return;
    }
    if (event.key !== "Tab") return;

    const focusable = [...locationDialog.querySelectorAll("button:not([disabled]), input:not([disabled])")];
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });
  locationInput.addEventListener("input", () => locationInput.setCustomValidity(""));
  locationForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const place = locationInput.value.trim();
    if (!place) {
      locationInput.setCustomValidity("Enter a city or area.");
      locationInput.reportValidity();
      return;
    }

    currentLocation = place;
    locationButton.textContent = `${place} ⌄`;
    closeLocationDialog();
  });

  document.querySelector("#signin").addEventListener("click", () => {
    window.location.href = "sign.html";
  });
  cart.addEventListener("click", () => {
    window.location.href = "cart.html";
  });
})();
