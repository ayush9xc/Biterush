const toastEl = document.getElementById('toast');
let toastTimer;

function toast(msg, showCartLink = false) {
  toastEl.replaceChildren();
  const message = document.createElement('span');
  message.textContent = msg;
  toastEl.appendChild(message);

  if (showCartLink) {
    const link = document.createElement('a');
    link.className = 'toast-cart-link';
    link.href = 'cart.html';
    link.textContent = 'View Cart';
    toastEl.appendChild(link);
  }

  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(
    () => {
      toastEl.classList.remove('show');
      toastEl.replaceChildren();
    },
    showCartLink ? 5000 : 2300,
  );
}

function updateCartBadge() {
  const count = window.BiteRushMenus.getCartCount();
  const badge = document.querySelector('#cartz .count');
  badge.textContent = count;
  document.getElementById('cartz').setAttribute('aria-label', `Shopping cart, ${count} items`);

  const selectedDishes = new Set(
    window.BiteRushMenus.getMenuCartItems().map((item) => item.id),
  );
  const selectedRestaurants = new Set(
    window.BiteRushMenus.getRestaurantSelections(),
  );
  document.querySelectorAll('[data-add-to-cart]').forEach((button) => {
    const menu = window.BiteRushMenus.restaurants[button.closest('.restaurant').dataset.menu];
    button.disabled =
      selectedDishes.has(menu.dishes[0].id) ||
      selectedRestaurants.has(menu.name);
    button.textContent = button.disabled ? 'Added' : 'Add to Cart';
    button.setAttribute('aria-pressed', String(button.disabled));
  });
}

function updateSliderControls(slider) {
  const maxScroll = slider.scrollWidth - slider.clientWidth;
  document
    .querySelectorAll(`[data-slider-target="${slider.id}"]`)
    .forEach((button) => {
      const direction = Number(button.dataset.sliderDirection);
      button.disabled =
        direction < 0 ? slider.scrollLeft <= 3 : slider.scrollLeft >= maxScroll - 3;
    });
}

document.querySelectorAll("[data-slider-target]").forEach((button) => {
  const slider = document.getElementById(button.dataset.sliderTarget);
  if (!slider) {
    console.error(`Slider target "${button.dataset.sliderTarget}" was not found.`);
    button.disabled = true;
    return;
  }

  button.addEventListener("click", () => {
    const firstCard = [...slider.children].find(
      (card) => card.getClientRects().length > 0,
    );
    const gap = Number.parseFloat(window.getComputedStyle(slider).columnGap) || 0;
    const step = firstCard
      ? firstCard.getBoundingClientRect().width + gap
      : slider.clientWidth * 0.8;
    const behavior = window.matchMedia("(prefers-reduced-motion: reduce)").matches
      ? "auto"
      : "smooth";
    slider.scrollBy({
      left: Number(button.dataset.sliderDirection) * step,
      behavior,
    });
  });

  slider.addEventListener("scroll", () => updateSliderControls(slider), {
    passive: true,
  });
  slider.addEventListener("scrollend", () => updateSliderControls(slider), {
    passive: true,
  });
  window.addEventListener("resize", () => updateSliderControls(slider));
  updateSliderControls(slider);
});

function selectCategory(cat) {
  document.querySelectorAll('.category').forEach((b) => {
    b.classList.toggle('active', b.dataset.category === cat);
  });

  document.querySelectorAll('.cuisine').forEach((b) => {
    b.classList.toggle('active', b.dataset.category === cat);
  });

  document.querySelectorAll('.restaurant').forEach((card) => {
    card.style.display =
      cat === 'All' || card.dataset.category === cat ? '' : 'none';
  });
  updateSliderControls(document.getElementById('restaurantGrid'));

  document.querySelector('.empty-results')?.remove();

  if (
    cat !== 'All' &&
    !Array.from(document.querySelectorAll('.restaurant')).some(
      (c) => c.style.display !== 'none'
    )
  ) {
    const e = document.createElement('div');
    e.className = 'empty-results';
    e.textContent = 'More ' + cat + ' options are coming soon. Try another cuisine!';
    document.getElementById('restaurantGrid').appendChild(e);
  }
}

document.querySelectorAll('[data-category]').forEach((b) => {
  b.addEventListener('click', () => {
    selectCategory(b.dataset.category);
    document.getElementById('restaurants').scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  });
});

document.getElementById('search').addEventListener('input', (e) => {
  const q = e.target.value.toLowerCase().trim();

  document.querySelectorAll('.restaurant').forEach((card) => {
    card.style.display =
      !q ||
      card.dataset.search.includes(q) ||
      card.textContent.toLowerCase().includes(q)
        ? ''
        : 'none';
  });

  document.querySelector('.empty-results')?.remove();

  if (
    q &&
    !Array.from(document.querySelectorAll('.restaurant')).some(
      (c) => c.style.display !== 'none'
    )
  ) {
    const empty = document.createElement('div');
    empty.className = 'empty-results';
    empty.textContent = 'No matching restaurants found. Try another search.';
    document.getElementById('restaurantGrid').appendChild(empty);
  }

  updateSliderControls(document.getElementById('restaurantGrid'));
});

document.querySelectorAll('nav a,.see-all').forEach((a) => {
  a.addEventListener('click', (e) => {
    if (a.hasAttribute('data-inert')) {
      e.preventDefault();
      return;
    }

    if (a.getAttribute('href') === '#') {
      e.preventDefault();
      toast('BiteRush ' + a.textContent.trim() + ' page can be connected next.');
    }
  });
});

document.querySelectorAll('[data-order]').forEach((button) => {
  button.addEventListener('click', (event) => {
    event.stopPropagation();
    const menu = window.BiteRushMenus.restaurants[
      button.closest('.restaurant').dataset.menu
    ];
    window.location.href = menu.page;
  });
});

document.querySelectorAll('[data-add-to-cart]').forEach((button) => {
  button.addEventListener('click', (event) => {
    event.stopPropagation();
    const restaurantId = button.closest('.restaurant').dataset.menu;
    const menu = window.BiteRushMenus.restaurants[restaurantId];
    const dish = menu.dishes[0];
    window.BiteRushMenus.addDishToCart(restaurantId, dish.id);
    updateCartBadge();
    toast(`${dish.name} added to your cart.`, true);
  });
});

updateCartBadge();
window.addEventListener('pageshow', updateCartBadge);

document.getElementById('cartz').addEventListener('click', () => {
  window.location.href = 'cart.html';
});

document.getElementById('location').addEventListener('click', () => {
  const button = document.getElementById('location');
  const currentLocation = button.textContent.trim().replace(/\s*⌄$/, '');
  const place = window.prompt('Enter your delivery location:', currentLocation);
  if (place && place.trim()) {
    button.textContent = `${place.trim()}　⌄`;
  }
});

document.getElementById('signin').addEventListener('click', () => {
  window.location.href = 'sign.html';
});

const categoryToggle = document.getElementById('categoryToggle');
const categorySidebar = document.getElementById('categorySidebar');
const categoryApp = document.querySelector('.app');
const categoryIntro = categorySidebar.querySelector('.category-intro');
const freeDeliveryCard = categorySidebar.querySelector('.free-card');
categoryToggle.addEventListener('click', () => {
  const expanded = categoryToggle.getAttribute('aria-expanded') === 'true';
  categoryToggle.setAttribute('aria-expanded', String(!expanded));
  categoryToggle.setAttribute('aria-label', expanded ? 'Show categories' : 'Hide categories');
  categoryToggle.querySelector('span').textContent = expanded ? 'Show' : 'Hide';
  categoryToggle.querySelector('b').textContent = expanded ? '›' : '‹';
  categorySidebar.classList.toggle('is-collapsed', expanded);
  categoryApp.classList.toggle('is-categories-collapsed', expanded);
  document.getElementById('categories').setAttribute('aria-hidden', String(expanded));
  document.getElementById('categories').toggleAttribute('inert', expanded);
  categoryIntro.setAttribute('aria-hidden', String(expanded));
  categoryIntro.toggleAttribute('inert', expanded);
  freeDeliveryCard.setAttribute('aria-hidden', String(expanded));
  freeDeliveryCard.toggleAttribute('inert', expanded);
});
