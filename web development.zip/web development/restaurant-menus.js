(() => {
  const restaurants = {
    mcdonalds: {
      name: "McDonald’s",
      page: "mcdonalds-menu.html",
      cuisine: "Burgers · Fast Food · American",
      rating: "4.5",
      reviews: "12K+",
      delivery: "25–35 mins",
      image: "mcdonalds.jpg",
      dishes: [
        {
          id: "mcdonalds-mcaloo-tikki",
          name: "McAloo Tikki Burger",
          description: "Crispy potato patty, fresh lettuce and tangy sauce.",
          price: 99,
          image: "menu-photos/mcdonalds-mcaloo-tikki.jpg",
        },
        {
          id: "mcdonalds-mcchicken",
          name: "McChicken Burger",
          description: "Seasoned chicken patty with lettuce and creamy sauce.",
          price: 169,
          image: "menu-photos/mcdonalds-mcchicken.jpg",
        },
        {
          id: "mcdonalds-cheeseburger",
          name: "Classic Cheeseburger",
          description: "Grilled patty with melted cheese and pickles.",
          price: 149,
          image: "menu-photos/mcdonalds-cheeseburger.jpg",
        },
      ],
    },
    dominos: {
      name: "Domino’s Pizza",
      page: "dominos-menu.html",
      cuisine: "Pizza · Italian",
      rating: "4.3",
      reviews: "8K+",
      delivery: "30–40 mins",
      image: "dominos.jpg",
      dishes: [
        {
          id: "dominos-margherita",
          name: "Margherita Pizza",
          description: "Classic mozzarella, tomato sauce and Italian herbs.",
          price: 199,
          image: "menu-photos/dominos-margherita.jpg",
        },
        {
          id: "dominos-farmhouse",
          name: "Farmhouse Pizza",
          description: "Loaded with capsicum, onion, tomato and mushrooms.",
          price: 399,
          image: "menu-photos/dominos-farmhouse.jpg",
        },
        {
          id: "dominos-bbq-chicken",
          name: "Pepper Barbecue Chicken",
          description: "Smoky chicken, barbecue sauce and golden cheese.",
          price: 429,
          image: "menu-photos/dominos-bbq-chicken.jpg",
        },
      ],
    },
    haldirams: {
      name: "Haldiram’s",
      page: "haldirams-menu.html",
      cuisine: "North Indian · Snacks · Indian",
      rating: "4.4",
      reviews: "5K+",
      delivery: "20–30 mins",
      image: "haldirams.jpg",
      dishes: [
        {
          id: "haldirams-chole-bhature",
          name: "Chole Bhature",
          description: "Fluffy bhature served with spiced chickpea curry.",
          price: 199,
          image: "menu-photos/haldirams-chole-bhature.jpg",
        },
        {
          id: "haldirams-raj-kachori",
          name: "Raj Kachori",
          description: "Crispy kachori filled with chutneys and yogurt.",
          price: 149,
          image: "menu-photos/haldirams-raj-kachori.jpg",
        },
        {
          id: "haldirams-paneer-tikka",
          name: "Paneer Tikka",
          description: "Tandoori paneer with peppers and a mint dip.",
          price: 249,
          image: "menu-photos/haldirams-paneer-tikka.jpg",
        },
      ],
    },
    chineseWok: {
      name: "Chinese Wok",
      page: "chinese-wok-menu.html",
      cuisine: "Chinese · Asian",
      rating: "4.2",
      reviews: "3K+",
      delivery: "30–40 mins",
      image: "chinese-wok.jpg",
      dishes: [
        {
          id: "chinese-wok-hakka-noodles",
          name: "Veg Hakka Noodles",
          description: "Wok-tossed noodles with crisp vegetables and soy.",
          price: 199,
          image: "menu-photos/chinese-wok-hakka-noodles.jpg",
        },
        {
          id: "chinese-wok-chilli-paneer",
          name: "Chilli Paneer",
          description: "Paneer tossed with peppers in a sweet-spicy sauce.",
          price: 249,
          image: "menu-photos/chinese-wok-chilli-paneer.jpg",
        },
        {
          id: "chinese-wok-chicken-manchurian",
          name: "Chicken Manchurian",
          description: "Crispy chicken bites in a savory wok sauce.",
          price: 279,
          image: "menu-photos/chinese-wok-chicken-manchurian.jpg",
        },
      ],
    },
    pizzaHut: {
      name: "Pizza Hut",
      page: "pizza-hut-menu.html",
      cuisine: "Pizza · Italian",
      rating: "4.4",
      reviews: "7K+",
      delivery: "30–40 mins",
      image: "pizza-hut.jpg",
      dishes: [
        {
          id: "pizza-hut-margherita",
          name: "Margherita",
          description: "A classic cheese pizza with tomato and herbs.",
          price: 199,
          image: "menu-photos/pizza-hut-margherita.jpg",
        },
        {
          id: "pizza-hut-tandoori-paneer",
          name: "Tandoori Paneer",
          description: "Paneer, onions and peppers with tandoori seasoning.",
          price: 349,
          image: "menu-photos/pizza-hut-tandoori-paneer.jpg",
        },
        {
          id: "pizza-hut-chicken-supreme",
          name: "Chicken Supreme",
          description: "A hearty pizza topped with chicken and cheese.",
          price: 399,
          image: "menu-photos/pizza-hut-chicken-supreme.jpg",
        },
      ],
    },
    wowMomo: {
      name: "Wow! Momo",
      page: "wow-momo-menu.html",
      cuisine: "Momos · Chinese",
      rating: "4.3",
      reviews: "6K+",
      delivery: "20–30 mins",
      image: "wow-momo.jpg",
      dishes: [
        {
          id: "wow-momo-steamed-veg",
          name: "Steamed Veg Momos",
          description: "Soft vegetable momos served with spicy chutney.",
          price: 119,
          image: "menu-photos/wow-momo-steamed-veg.jpg",
        },
        {
          id: "wow-momo-chicken",
          name: "Darjeeling Chicken Momos",
          description: "Juicy chicken filling wrapped in delicate dough.",
          price: 159,
          image: "menu-photos/wow-momo-chicken.jpg",
        },
        {
          id: "wow-momo-pan-fried-paneer",
          name: "Pan-Fried Paneer Momos",
          description: "Golden paneer momos with a tangy dipping sauce.",
          price: 179,
          image: "menu-photos/wow-momo-pan-fried-paneer.jpg",
        },
      ],
    },
    barbequeNation: {
      name: "Barbeque Nation",
      page: "barbeque-nation-menu.html",
      cuisine: "Barbeque · North Indian",
      rating: "4.6",
      reviews: "10K+",
      delivery: "35–45 mins",
      image: "barbeque-nation.jpg",
      dishes: [
        {
          id: "barbeque-nation-crispy-corn",
          name: "Crispy Corn",
          description: "Crunchy corn tossed with peppers and seasoning.",
          price: 199,
          image: "menu-photos/barbeque-nation-crispy-corn.jpg",
        },
        {
          id: "barbeque-nation-paneer-tikka",
          name: "Paneer Tikka",
          description: "Chargrilled paneer with smoky spices.",
          price: 249,
          image: "menu-photos/barbeque-nation-paneer-tikka.jpg",
        },
        {
          id: "barbeque-nation-chicken-tikka",
          name: "Chicken Tikka",
          description: "Tender chicken pieces marinated and grilled.",
          price: 299,
          image: "menu-photos/barbeque-nation-chicken-tikka.jpg",
        },
      ],
    },
    theobroma: {
      name: "Theobroma",
      page: "theobroma-menu.html",
      cuisine: "Desserts · Bakery",
      rating: "4.7",
      reviews: "4K+",
      delivery: "25–35 mins",
      image: "theobroma.jpg",
      dishes: [
        {
          id: "theobroma-truffle-pastry",
          name: "Chocolate Truffle Pastry",
          description: "Rich chocolate layers with smooth truffle icing.",
          price: 159,
          image: "menu-photos/theobroma-truffle-pastry.jpg",
        },
        {
          id: "theobroma-brownie",
          name: "Chocolate Brownie",
          description: "A fudgy chocolate brownie baked until just set.",
          price: 129,
          image: "menu-photos/theobroma-brownie.jpg",
        },
        {
          id: "theobroma-red-velvet",
          name: "Red Velvet Cupcake",
          description: "Soft red velvet sponge with cream cheese frosting.",
          price: 119,
          image: "menu-photos/theobroma-red-velvet.jpg",
        },
      ],
    },
    kfc: {
      name: "KFC",
      page: "kfc-menu.html",
      cuisine: "Chicken · American",
      rating: "4.5",
      reviews: "9K+",
      delivery: "25–35 mins",
      image: "kfc.jpg",
      dishes: [
        {
          id: "kfc-hot-crispy",
          name: "Hot & Crispy Chicken",
          description: "Crispy fried chicken with KFC-style seasoning.",
          price: 199,
          image: "menu-photos/kfc-hot-crispy.jpg",
        },
        {
          id: "kfc-zinger-burger",
          name: "Zinger Burger",
          description: "Crunchy chicken fillet in a toasted sesame bun.",
          price: 199,
          image: "menu-photos/kfc-zinger-burger.jpg",
        },
        {
          id: "kfc-popcorn-chicken",
          name: "Popcorn Chicken",
          description: "Bite-size pieces of crispy seasoned chicken.",
          price: 149,
          image: "menu-photos/kfc-popcorn-chicken.jpg",
        },
      ],
    },
  };

  const menuCartKey = "biterushMenuCart";
  const menuCartVersionKey = "biterushMenuCartVersion";
  const restaurantSelectionsKey = "biterushRestaurantSelections";
  const initialCartItems = [
    {
      id: "sample-classic-cheeseburger",
      name: "Classic Cheeseburger",
      description: "Juicy grilled patty, fresh lettuce, tomato, cheese, special sauce",
      price: 149,
      quantity: 1,
      sample: true,
      emoji: "🍔",
      tag: "Non-Veg",
      restaurantName: "BiteRush",
    },
    {
      id: "sample-peri-peri-fries",
      name: "Peri Peri Fries",
      description: "Crispy fries tossed in our special peri peri spice blend",
      price: 99,
      quantity: 1,
      sample: true,
      emoji: "🍟",
      foodClass: "fries",
      tag: "Veg",
      tagClass: "veg",
      restaurantName: "BiteRush",
    },
    {
      id: "sample-coke",
      name: "Coke (500ml)",
      description: "Chilled and refreshing",
      price: 40,
      quantity: 1,
      sample: true,
      emoji: "🥤",
      foodClass: "drink",
      tag: "Veg",
      tagClass: "green",
      restaurantName: "BiteRush",
    },
  ];

  function getMenuCartItems() {
    const savedItems = localStorage.getItem(menuCartKey);
    if (savedItems === null) {
      return initialCartItems.map((item) => ({ ...item }));
    }

    const items = JSON.parse(savedItems);
    if (localStorage.getItem(menuCartVersionKey) !== "1") {
      const migratedItems = [
        ...initialCartItems.map((item) => ({ ...item })),
        ...items,
      ];
      saveMenuCartItems(migratedItems);
      return migratedItems;
    }
    return items;
  }

  function saveMenuCartItems(items) {
    localStorage.setItem(menuCartKey, JSON.stringify(items));
    localStorage.setItem(menuCartVersionKey, "1");
  }

  function getRestaurantSelections() {
    return (localStorage.getItem(restaurantSelectionsKey) || "")
      .split("\n")
      .filter(Boolean);
  }

  function getCartCount() {
    const cartItemCount = getMenuCartItems().reduce(
      (total, item) => total + item.quantity,
      0,
    );
    return cartItemCount + getRestaurantSelections().length;
  }

  function removeRestaurantSelection(restaurantName) {
    const remainingSelections = getRestaurantSelections().filter(
      (name) => name !== restaurantName,
    );
    localStorage.setItem(restaurantSelectionsKey, remainingSelections.join("\n"));
  }

  function addDishToCart(restaurantId, dishId) {
    const restaurant = restaurants[restaurantId];
    if (!restaurant) throw new Error(`Unknown restaurant: ${restaurantId}`);

    const dish = restaurant.dishes.find((item) => item.id === dishId);
    if (!dish) throw new Error(`Unknown dish: ${dishId}`);

    const items = getMenuCartItems();
    const existing = items.find((item) => item.id === dish.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      items.push({
        ...dish,
        restaurantId,
        restaurantName: restaurant.name,
        quantity: 1,
      });
    }
    saveMenuCartItems(items);

    removeRestaurantSelection(restaurant.name);

    return dish;
  }

  function addDealToCart(restaurantId, dishId, dealId, dealName, dealPrice) {
    const restaurant = restaurants[restaurantId];
    if (!restaurant) throw new Error(`Unknown restaurant: ${restaurantId}`);

    const dish = restaurant.dishes.find((item) => item.id === dishId);
    if (!dish) throw new Error(`Unknown dish: ${dishId}`);

    if (!dealId || !dealName || !Number.isFinite(dealPrice) ||
        dealPrice <= 0 || dealPrice >= dish.price) {
      throw new Error(`Invalid deal for dish: ${dishId}`);
    }

    const cartItemId = `${dish.id}-deal-${dealId}`;
    const items = getMenuCartItems();
    const existing = items.find((item) => item.id === cartItemId);
    if (existing) {
      existing.quantity += 1;
    } else {
      items.push({
        ...dish,
        id: cartItemId,
        originalDishId: dish.id,
        originalPrice: dish.price,
        price: dealPrice,
        dealId,
        dealName,
        restaurantId,
        restaurantName: restaurant.name,
        quantity: 1,
      });
    }
    saveMenuCartItems(items);
    removeRestaurantSelection(restaurant.name);

    return items.find((item) => item.id === cartItemId);
  }

  window.BiteRushMenus = {
    restaurants,
    getCartCount,
    getMenuCartItems,
    getRestaurantSelections,
    saveMenuCartItems,
    addDishToCart,
    addDealToCart,
  };
})();
